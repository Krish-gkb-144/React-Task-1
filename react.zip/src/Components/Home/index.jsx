import React from "react";
import User from "./User";

const Home = () => {
  return (
    <>
      <User />
    </>
  );
};

export default Home;
