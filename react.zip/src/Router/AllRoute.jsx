export const AllRoute = {
  Login: "/",
  Home: "/home",
  Card: "/card",
};
