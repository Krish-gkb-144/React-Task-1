export const API = {
  auth: {
    LOG_IN: "https://dummyjson.com/auth/login",
  },
  movieList: {
    SHOWS: "https://api.tvmaze.com/shows",
  },
};
